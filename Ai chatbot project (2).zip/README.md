# Histogram - Interactive History Chatbot

Histogram is an engaging history-themed chatbot that serves as a virtual history tutor. With its unique personality and blackboard-themed interface, it makes learning history fun and interactive.

## Features

- Modern blackboard-themed web interface
- Integration with Google Gemini API for intelligent responses
- Historical facts from Numbers API
- Interactive chat functionality
- Responsive design with chalk-style animations

## Setup

1. Create a `.env` file in the project root with your API keys:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the application:
   ```bash
   python app.py
   ```

4. Open your browser and navigate to `http://localhost:5000`

## Tech Stack

- Backend: Python/Flask
- Frontend: HTML/CSS/JavaScript
- APIs: Google Gemini API, Numbers API
- WebSocket: Flask-SocketIO

## Project Structure

```
.
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── .env               # Environment variables (create this)
├── static/
│   ├── css/
│   │   └── style.css  # Blackboard theme styles
│   └── js/
│       └── main.js    # Frontend interactions
└── templates/
    └── index.html     # Main chat interface
```

## Usage

1. Start a conversation by asking any history-related question
2. The chatbot will respond with relevant information and facts
3. Enjoy learning history in an interactive way!
