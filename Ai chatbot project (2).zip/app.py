from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
from flask_cors import CORS
import os
import google.generativeai as genai
from dotenv import load_dotenv
import requests
import json

# Define constants
NUMBERS_API_BASE = "http://numbersapi.com"

# Enable debug logging
import logging
logging.basicConfig(level=logging.DEBUG)

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Log when the application starts
app.logger.info('Application starting...')

# Configure Google Gemini API
api_key = os.getenv('GEMINI_API_KEY')
if not api_key:
    raise ValueError('GEMINI_API_KEY environment variable is not set')

print(f"Using API key: {api_key[:5]}...{api_key[-4:]}")
genai.configure(api_key=api_key)

# Initialize Gemini 2.0 Flash model for faster performance
model = genai.GenerativeModel('gemini-2.0-flash')

# Set up chat history and context management
history = []

# Configure chat-specific settings with Gemini 2.0
chat = model.start_chat(history=history)

# Define system prompt for historical context with structured formatting
SYSTEM_PROMPT = """
You are a knowledgeable AI assistant specializing in historical facts and events.

FORMATTING RULES:
1. Always start with a '**Main Topic**' as the main heading
2. Organize information under clear '**Subheadings**' in bold
3. Break down complex topics into smaller sections
4. Use bullet points for key events or facts
5. Start each new section with a bold heading
6. Add dates in parentheses where relevant
7. Keep paragraphs short and focused
8. Use markdown formatting

Example format:
**Main Topic**
Brief overview paragraph

**Key Events**
• Event 1 (date)
• Event 2 (date)

**Impact and Significance**
Explanatory paragraph

Provide accurate, engaging responses following this structured format.
"""

# Configure the model with safety settings
generation_config = {
    "temperature": 0.9,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_NONE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_NONE"
    },
]

# Numbers API base URL for historical facts
NUMBERS_API_BASE = "http://numbersapi.com"

def get_historical_fact(year=None):
    """Get a random historical fact from Numbers API"""
    if year:
        url = f"{NUMBERS_API_BASE}/{year}/year"
    else:
        url = f"{NUMBERS_API_BASE}/random/year"
    try:
        response = requests.get(url)
        return response.text if response.status_code == 200 else None
    except:
        return None

def generate_response(user_input):
    """Generate response using Gemini API with chat history"""
    try:
        app.logger.info(f'Generating response for input: {user_input}')
        
        # Prepare the message with historical context
        message = f"{SYSTEM_PROMPT}\n\nUser: {user_input}"
        
        app.logger.info('Calling Gemini API with chat...')
        # Generate response using chat
        response = chat.send_message(
            message,
            generation_config=generation_config,
            safety_settings=safety_settings
        )
        
        # Check if we have a valid response
        if not response:
            app.logger.error("Null response from Gemini API")
            return "I apologize, but I'm having trouble understanding that. Could you rephrase your question?"
        
        if not hasattr(response, 'text'):
            app.logger.error(f"Invalid response format from Gemini API: {response}")
            return "I apologize, but I received an invalid response format. Could you try again?"
        
        text = response.text.strip()
        if not text:
            app.logger.error("Empty text in Gemini API response")
            return "I apologize, but I'm having trouble formulating a response. Could you rephrase your question?"
            
        app.logger.info(f'Successfully generated response: {text[:100]}...')
        return text
        
    except Exception as e:
        error_msg = str(e)
        app.logger.error(f"Error in generate_response: {error_msg}")
        
        if 'quota exceeded' in error_msg.lower():
            return "I apologize, but we've reached our API quota. Please try again later."
        elif 'invalid api key' in error_msg.lower():
            return "There seems to be an issue with the API configuration. Please contact support."
        else:
            return "I apologize, but I'm having trouble processing your request. Could you try asking another question?"

@app.route('/')
def home():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    app.logger.info('Client connected')

@socketio.on('send_message')
def handle_message(data):
    try:
        user_message = data['message']
        app.logger.info(f'Received message: {user_message}')
        
        # Generate bot response
        bot_response = generate_response(user_message)
        app.logger.info(f'Generated response: {bot_response}')
        
        if not bot_response:
            raise Exception('Empty response from generate_response')
        
        # Get a random historical fact
        historical_fact = get_historical_fact()
        if historical_fact:
            app.logger.info(f'Got historical fact: {historical_fact}')
        
        # Combine response with historical fact if available
        final_response = bot_response
        if historical_fact:
            final_response = f"{bot_response}\n\nHere's an interesting historical fact: {historical_fact}"
        
        # Send response back to client
        app.logger.info(f'Sending final response: {final_response}')
        emit('receive_message', {
            'message': final_response,
            'sender': 'bot'
        })
    except Exception as e:
        app.logger.error(f'Error in handle_message: {str(e)}')
        emit('receive_message', {
            'message': 'I apologize, but I encountered an error. Please try again.',
            'sender': 'bot'
        })

if __name__ == '__main__':
    socketio.run(app, debug=True)
