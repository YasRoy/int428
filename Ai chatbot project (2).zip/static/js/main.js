document.addEventListener('DOMContentLoaded', () => {
    // Historical icons click handling
    const icons = document.querySelectorAll('.icon');
    let activeIcon = null;

    icons.forEach(icon => {
        icon.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent document click from immediately closing
            
            if (activeIcon === icon) {
                // If clicking the same icon, close it
                icon.classList.remove('active');
                activeIcon = null;
            } else {
                // Close any open icon
                if (activeIcon) {
                    activeIcon.classList.remove('active');
                }
                // Open the clicked icon
                icon.classList.add('active');
                activeIcon = icon;
            }
        });
    });

    // Close active icon when clicking outside
    document.addEventListener('click', () => {
        if (activeIcon) {
            activeIcon.classList.remove('active');
            activeIcon = null;
        }
    });

    // Initialize Socket.IO with explicit connection URL
    const socket = io('http://127.0.0.1:5000');

    const chatContainer = document.getElementById('chatContainer');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const newChatButton = document.getElementById('newChatButton');
    const eraserAnimation = document.getElementById('eraserAnimation');

    // Connection status handling
    socket.on('connect', () => {
        console.log('Connected to server');
        // Add welcome message when connected
        // addMessage('Welcome to our history class! I am Histogram, your history tutor. What period of history would you like to explore today?', 'bot');
    });

    socket.on('connect_error', (error) => {
        console.error('Connection error:', error);
    });

    function addMessage(content, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        // Use marked.js to render markdown for bot messages
        if (sender === 'bot') {
            // Configure marked options
            marked.setOptions({
                breaks: true,  // Add line breaks
                gfm: true,    // Enable GitHub Flavored Markdown
            });
            messageContent.innerHTML = marked.parse(content);
        } else {
            messageContent.textContent = content;
        }
        
        messageDiv.appendChild(messageContent);
        chatContainer.appendChild(messageDiv);
        
        // Scroll to bottom
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    function sendMessage() {
        const message = userInput.value.trim();
        if (message) {
            console.log('Sending message:', message);
            
            // Add user message to chat
            addMessage(message, 'user');
            
            // Send message to server
            socket.emit('send_message', { message: message }, (error) => {
                if (error) {
                    console.error('Error sending message:', error);
                    addMessage('Error sending message. Please try again.', 'bot');
                } else {
                    console.log('Message sent successfully');
                }
            });
            
            // Clear input
            userInput.value = '';
        }
    }

    // Handle send button click
    sendButton.addEventListener('click', sendMessage);

    // Handle enter key
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Handle new chat button
    newChatButton.addEventListener('click', () => {
        // Show eraser animation
        eraserAnimation.classList.add('active');
        
        // After animation completes
        setTimeout(() => {
            // Clear chat container with a wiping effect
            const messages = chatContainer.querySelectorAll('.message');
            messages.forEach((msg, index) => {
                setTimeout(() => {
                    msg.style.opacity = '0';
                    msg.style.transform = 'translateX(100px)';
                    setTimeout(() => msg.remove(), 500);
                }, index * 100);
            });

            // Hide eraser animation
            setTimeout(() => {
                eraserAnimation.classList.remove('active');
                
                // Add welcome message
                setTimeout(() => {
                    addMessage('Chat cleared! Feel free to ask another question about history.', 'bot');
                }, 500);
            }, 2000);
        }, 500);
    });

    // Handle received messages
    socket.on('receive_message', (data) => {
        console.log('Received message:', data);
        addMessage(data.message, data.sender);
    });

    // Handle any errors
    socket.on('error', (error) => {
        console.error('Socket error:', error);
        addMessage('Sorry, there was an error processing your request.', 'bot');
    });
});
